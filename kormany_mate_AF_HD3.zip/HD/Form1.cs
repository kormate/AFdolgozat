﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace HD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        struct Orszag
        {
            public int sorszam;
            public string orszagneve;
            public string fovarosa;
            public int terulete;
            public double lakossag;
            public string egtaj;
            public bool eutag;
        }

        List<Orszag> olista = new List<Orszag>();

        const string fajl = @"Europa.txt";
        const char elvalasztas = '\t';

        void fajlBeo()
        {
            /*string[] lines = File.ReadAllLines(fajl);
            string[] values;

            for (int i = 0; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(elvalasztas);
                string[] row = new string[values.Length];

                for (int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }

                table.Rows.Add(row);
            }*/

            FileStream fs = new FileStream(fajl, FileMode.Open);
            StreamReader sr = new StreamReader(fs);


            while (!sr.EndOfStream)
            {
                string[] sor = sr.ReadLine().Split(elvalasztas);
                Orszag orszag = new Orszag();
                orszag.sorszam = Convert.ToInt32(sor[0]);
                orszag.orszagneve = sor[1];
                orszag.fovarosa = sor[2];
                orszag.terulete = Convert.ToInt32(sor[3]);
                orszag.lakossag = Convert.ToDouble(sor[4]);
                orszag.egtaj = sor[5];
                if (sor[5] == "1") orszag.eutag = true;
                else orszag.eutag = false;
                olista.Add(orszag);
            }
            sr.Close();
            fs.Close();
        }

        void tablaFeltoltes()
        {
            foreach (Orszag orszag in olista)
                adat.Rows.Add(orszag.sorszam,
                    orszag.orszagneve);

        }


        private void frissitButton_Click(object sender, EventArgs e)
        {
            tablaFeltoltes();
            pluszButton.Enabled = true;
            keresesButton.Enabled = true;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }


        DataTable table = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            fajlBeo();
            /*table.Columns.Add("Sorszám", typeof(int));
            table.Columns.Add("Ország neve", typeof(string));

            adat.DataSource = table;*/

        }
    }
}
