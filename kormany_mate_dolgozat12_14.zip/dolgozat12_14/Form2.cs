﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dolgozat12_14
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void eredmenyButton_Click(object sender, EventArgs e)
        {
            try
            {
                int szokoev = int.Parse(szokoevTextBox.Text);
                if (szokoev < 0)
                {
                    MessageBox.Show("Nullánál nagyobb számot adj meg!");
                }
                else if (szokoev % 4 == 0 && szokoev % 100 != 0 || szokoev % 400 == 0)
                {
                    eredmenyLabel.Text = "Szökőév";
                }
                else 
                {
                    eredmenyLabel.Text = "Nem szökőév";
                }
            } 
            catch 
            {
                MessageBox.Show("Csak számot adhatsz meg!");
            }
        }
    }
}
