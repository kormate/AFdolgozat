﻿namespace dolgozat12_14
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.szokoevTextBox = new System.Windows.Forms.TextBox();
            this.eredmenyButton = new System.Windows.Forms.Button();
            this.eredmenyLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(103, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kérem az évszámot:";
            // 
            // szokoevTextBox
            // 
            this.szokoevTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.szokoevTextBox.Location = new System.Drawing.Point(106, 96);
            this.szokoevTextBox.Name = "szokoevTextBox";
            this.szokoevTextBox.Size = new System.Drawing.Size(134, 20);
            this.szokoevTextBox.TabIndex = 1;
            // 
            // eredmenyButton
            // 
            this.eredmenyButton.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.eredmenyButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.eredmenyButton.Location = new System.Drawing.Point(118, 140);
            this.eredmenyButton.Name = "eredmenyButton";
            this.eredmenyButton.Size = new System.Drawing.Size(109, 36);
            this.eredmenyButton.TabIndex = 2;
            this.eredmenyButton.Text = "Eredmény";
            this.eredmenyButton.UseVisualStyleBackColor = false;
            this.eredmenyButton.Click += new System.EventHandler(this.eredmenyButton_Click);
            // 
            // eredmenyLabel
            // 
            this.eredmenyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.eredmenyLabel.Location = new System.Drawing.Point(94, 203);
            this.eredmenyLabel.Name = "eredmenyLabel";
            this.eredmenyLabel.Size = new System.Drawing.Size(154, 29);
            this.eredmenyLabel.TabIndex = 3;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 274);
            this.Controls.Add(this.eredmenyLabel);
            this.Controls.Add(this.eredmenyButton);
            this.Controls.Add(this.szokoevTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Szökőév";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox szokoevTextBox;
        private System.Windows.Forms.Button eredmenyButton;
        private System.Windows.Forms.Label eredmenyLabel;
    }
}