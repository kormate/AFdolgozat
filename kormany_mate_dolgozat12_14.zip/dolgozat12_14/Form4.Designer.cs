﻿namespace dolgozat12_14
{
    partial class Teszt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.prim1 = new System.Windows.Forms.RadioButton();
            this.prim17 = new System.Windows.Forms.RadioButton();
            this.prim27 = new System.Windows.Forms.RadioButton();
            this.negyzet2 = new System.Windows.Forms.RadioButton();
            this.negyzet44 = new System.Windows.Forms.RadioButton();
            this.negyzet36 = new System.Windows.Forms.RadioButton();
            this.gyok25 = new System.Windows.Forms.RadioButton();
            this.gyok105 = new System.Windows.Forms.RadioButton();
            this.gyok125 = new System.Windows.Forms.RadioButton();
            this.primLabel = new System.Windows.Forms.Label();
            this.gyokLabel = new System.Windows.Forms.Label();
            this.negyzetLabel = new System.Windows.Forms.Label();
            this.kiertekelButton = new System.Windows.Forms.Button();
            this.torolButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.primLabel);
            this.groupBox1.Controls.Add(this.prim27);
            this.groupBox1.Controls.Add(this.prim17);
            this.groupBox1.Controls.Add(this.prim1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.Location = new System.Drawing.Point(107, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(247, 94);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Melyik prímszám?";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.negyzetLabel);
            this.groupBox2.Controls.Add(this.negyzet36);
            this.groupBox2.Controls.Add(this.negyzet44);
            this.groupBox2.Controls.Add(this.negyzet2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox2.Location = new System.Drawing.Point(107, 202);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(247, 94);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Melyik négyzetszám?";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.gyokLabel);
            this.groupBox3.Controls.Add(this.gyok125);
            this.groupBox3.Controls.Add(this.gyok105);
            this.groupBox3.Controls.Add(this.gyok25);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox3.Location = new System.Drawing.Point(107, 349);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(247, 94);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mennyi 625 négyzetgyöke?";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // prim1
            // 
            this.prim1.AutoSize = true;
            this.prim1.Location = new System.Drawing.Point(32, 22);
            this.prim1.Name = "prim1";
            this.prim1.Size = new System.Drawing.Size(34, 21);
            this.prim1.TabIndex = 0;
            this.prim1.TabStop = true;
            this.prim1.Text = "1";
            this.prim1.UseVisualStyleBackColor = true;
            this.prim1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // prim17
            // 
            this.prim17.AutoSize = true;
            this.prim17.Location = new System.Drawing.Point(93, 22);
            this.prim17.Name = "prim17";
            this.prim17.Size = new System.Drawing.Size(42, 21);
            this.prim17.TabIndex = 1;
            this.prim17.TabStop = true;
            this.prim17.Text = "17";
            this.prim17.UseVisualStyleBackColor = true;
            // 
            // prim27
            // 
            this.prim27.AutoSize = true;
            this.prim27.Location = new System.Drawing.Point(167, 22);
            this.prim27.Name = "prim27";
            this.prim27.Size = new System.Drawing.Size(42, 21);
            this.prim27.TabIndex = 2;
            this.prim27.TabStop = true;
            this.prim27.Text = "27";
            this.prim27.UseVisualStyleBackColor = true;
            // 
            // negyzet2
            // 
            this.negyzet2.AutoSize = true;
            this.negyzet2.Location = new System.Drawing.Point(32, 22);
            this.negyzet2.Name = "negyzet2";
            this.negyzet2.Size = new System.Drawing.Size(34, 21);
            this.negyzet2.TabIndex = 3;
            this.negyzet2.TabStop = true;
            this.negyzet2.Text = "2";
            this.negyzet2.UseVisualStyleBackColor = true;
            // 
            // negyzet44
            // 
            this.negyzet44.AutoSize = true;
            this.negyzet44.Location = new System.Drawing.Point(93, 22);
            this.negyzet44.Name = "negyzet44";
            this.negyzet44.Size = new System.Drawing.Size(42, 21);
            this.negyzet44.TabIndex = 4;
            this.negyzet44.TabStop = true;
            this.negyzet44.Text = "44";
            this.negyzet44.UseVisualStyleBackColor = true;
            // 
            // negyzet36
            // 
            this.negyzet36.AutoSize = true;
            this.negyzet36.Location = new System.Drawing.Point(167, 22);
            this.negyzet36.Name = "negyzet36";
            this.negyzet36.Size = new System.Drawing.Size(42, 21);
            this.negyzet36.TabIndex = 5;
            this.negyzet36.TabStop = true;
            this.negyzet36.Text = "36";
            this.negyzet36.UseVisualStyleBackColor = true;
            // 
            // gyok25
            // 
            this.gyok25.AutoSize = true;
            this.gyok25.Location = new System.Drawing.Point(32, 22);
            this.gyok25.Name = "gyok25";
            this.gyok25.Size = new System.Drawing.Size(42, 21);
            this.gyok25.TabIndex = 6;
            this.gyok25.TabStop = true;
            this.gyok25.Text = "25";
            this.gyok25.UseVisualStyleBackColor = true;
            // 
            // gyok105
            // 
            this.gyok105.AutoSize = true;
            this.gyok105.Location = new System.Drawing.Point(93, 22);
            this.gyok105.Name = "gyok105";
            this.gyok105.Size = new System.Drawing.Size(50, 21);
            this.gyok105.TabIndex = 7;
            this.gyok105.TabStop = true;
            this.gyok105.Text = "105";
            this.gyok105.UseVisualStyleBackColor = true;
            // 
            // gyok125
            // 
            this.gyok125.AutoSize = true;
            this.gyok125.Location = new System.Drawing.Point(159, 22);
            this.gyok125.Name = "gyok125";
            this.gyok125.Size = new System.Drawing.Size(50, 21);
            this.gyok125.TabIndex = 8;
            this.gyok125.TabStop = true;
            this.gyok125.Text = "125";
            this.gyok125.UseVisualStyleBackColor = true;
            // 
            // primLabel
            // 
            this.primLabel.Location = new System.Drawing.Point(67, 61);
            this.primLabel.Name = "primLabel";
            this.primLabel.Size = new System.Drawing.Size(118, 30);
            this.primLabel.TabIndex = 3;
            this.primLabel.Text = "label1";
            this.primLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.primLabel.Click += new System.EventHandler(this.primLabel_Click);
            // 
            // gyokLabel
            // 
            this.gyokLabel.Location = new System.Drawing.Point(64, 61);
            this.gyokLabel.Name = "gyokLabel";
            this.gyokLabel.Size = new System.Drawing.Size(118, 30);
            this.gyokLabel.TabIndex = 4;
            this.gyokLabel.Text = "label1";
            this.gyokLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // negyzetLabel
            // 
            this.negyzetLabel.Location = new System.Drawing.Point(64, 64);
            this.negyzetLabel.Name = "negyzetLabel";
            this.negyzetLabel.Size = new System.Drawing.Size(118, 30);
            this.negyzetLabel.TabIndex = 5;
            this.negyzetLabel.Text = "label1";
            this.negyzetLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // kiertekelButton
            // 
            this.kiertekelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kiertekelButton.Location = new System.Drawing.Point(139, 476);
            this.kiertekelButton.Name = "kiertekelButton";
            this.kiertekelButton.Size = new System.Drawing.Size(170, 42);
            this.kiertekelButton.TabIndex = 3;
            this.kiertekelButton.Text = "Kiértékel";
            this.kiertekelButton.UseVisualStyleBackColor = true;
            this.kiertekelButton.Click += new System.EventHandler(this.kiertekelButton_Click);
            // 
            // torolButton
            // 
            this.torolButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.torolButton.Location = new System.Drawing.Point(139, 550);
            this.torolButton.Name = "torolButton";
            this.torolButton.Size = new System.Drawing.Size(170, 42);
            this.torolButton.TabIndex = 4;
            this.torolButton.Text = "Töröl";
            this.torolButton.UseVisualStyleBackColor = true;
            this.torolButton.Click += new System.EventHandler(this.kilepButton_Click);
            // 
            // Teszt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 605);
            this.Controls.Add(this.torolButton);
            this.Controls.Add(this.kiertekelButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Teszt";
            this.Text = "Teszt";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton prim1;
        private System.Windows.Forms.RadioButton prim27;
        private System.Windows.Forms.RadioButton prim17;
        private System.Windows.Forms.RadioButton negyzet44;
        private System.Windows.Forms.RadioButton negyzet2;
        private System.Windows.Forms.RadioButton negyzet36;
        private System.Windows.Forms.Label primLabel;
        private System.Windows.Forms.RadioButton gyok125;
        private System.Windows.Forms.RadioButton gyok105;
        private System.Windows.Forms.RadioButton gyok25;
        private System.Windows.Forms.Label negyzetLabel;
        private System.Windows.Forms.Label gyokLabel;
        private System.Windows.Forms.Button kiertekelButton;
        private System.Windows.Forms.Button torolButton;
    }
}