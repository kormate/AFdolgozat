﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dolgozat12_14
{
    public partial class Teszt : Form
    {
        public Teszt()
        {
            InitializeComponent();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void primLabel_Click(object sender, EventArgs e)
        {

        }

        private void kilepButton_Click(object sender, EventArgs e)
        {
            
        }

        private void kiertekelButton_Click(object sender, EventArgs e)
        {
            try 
            {

                if (prim17.Checked)
                {
                    primLabel.ForeColor = Color.Green;
                    primLabel.Text = "Helyes";
                }
                else if (!prim17.Checked) 
                {
                    primLabel.ForeColor = Color.Red;
                    primLabel.Text = "Helytelen";
                }

                if (!negyzet44.Checked)
                {
                    negyzetLabel.ForeColor = Color.Red;
                    negyzetLabel.Text = "Helytelen";
                }
                else if (negyzet44.Checked)
                {
                    negyzetLabel.ForeColor = Color.Green;
                    negyzetLabel.Text = "Helyes";
                }

                if (gyok25.Checked) 
                {
                    gyokLabel.ForeColor = Color.Green;
                    gyokLabel.Text = "Helyes";
                }
                else if (!gyok25.Checked) 
                {
                    gyokLabel.ForeColor= Color.Red;
                    gyokLabel.Text = "Helytelen";
                }
                

            }
            catch 
            {
                MessageBox.Show("Kérlek jelölj meg egy választ!");
            }
        }
    }
}
