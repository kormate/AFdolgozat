﻿namespace dolgozat12_14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.szökőévToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.intervallumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tesztToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.véletlenszámokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.szobafoglalásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.készítetteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.szökőévToolStripMenuItem,
            this.intervallumToolStripMenuItem,
            this.tesztToolStripMenuItem,
            this.véletlenszámokToolStripMenuItem,
            this.szobafoglalásToolStripMenuItem,
            this.készítetteToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(733, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // szökőévToolStripMenuItem
            // 
            this.szökőévToolStripMenuItem.Name = "szökőévToolStripMenuItem";
            this.szökőévToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.szökőévToolStripMenuItem.Text = "Szökőév";
            this.szökőévToolStripMenuItem.Click += new System.EventHandler(this.szökőévToolStripMenuItem_Click);
            // 
            // intervallumToolStripMenuItem
            // 
            this.intervallumToolStripMenuItem.Name = "intervallumToolStripMenuItem";
            this.intervallumToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.intervallumToolStripMenuItem.Text = "Intervallum";
            this.intervallumToolStripMenuItem.Click += new System.EventHandler(this.intervallumToolStripMenuItem_Click);
            // 
            // tesztToolStripMenuItem
            // 
            this.tesztToolStripMenuItem.Name = "tesztToolStripMenuItem";
            this.tesztToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.tesztToolStripMenuItem.Text = "Teszt";
            this.tesztToolStripMenuItem.Click += new System.EventHandler(this.tesztToolStripMenuItem_Click);
            // 
            // véletlenszámokToolStripMenuItem
            // 
            this.véletlenszámokToolStripMenuItem.Enabled = false;
            this.véletlenszámokToolStripMenuItem.Name = "véletlenszámokToolStripMenuItem";
            this.véletlenszámokToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.véletlenszámokToolStripMenuItem.Text = "Véletlenszámok";
            // 
            // szobafoglalásToolStripMenuItem
            // 
            this.szobafoglalásToolStripMenuItem.Enabled = false;
            this.szobafoglalásToolStripMenuItem.Name = "szobafoglalásToolStripMenuItem";
            this.szobafoglalásToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.szobafoglalásToolStripMenuItem.Text = "Szobafoglalás";
            // 
            // készítetteToolStripMenuItem
            // 
            this.készítetteToolStripMenuItem.Name = "készítetteToolStripMenuItem";
            this.készítetteToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.készítetteToolStripMenuItem.Text = "Készítette";
            this.készítetteToolStripMenuItem.Click += new System.EventHandler(this.készítetteToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Dolgozat - 2023. 12. 14.";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem szökőévToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem intervallumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tesztToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem véletlenszámokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem szobafoglalásToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem készítetteToolStripMenuItem;
    }
}

