﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dolgozat12_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void készítetteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Kormány Máté");
        }

        private void szökőévToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form szokoev = new Form2();
            szokoev.Show();
        }

        private void intervallumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form intervallum = new Form3();
            intervallum.Show();
        }

        private void tesztToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form tesztes = new Teszt();
            tesztes.Show();
        }
    }
}
