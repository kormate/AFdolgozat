﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HD_OOP2
{
    internal class Orszagok
    {
        private int serialnum;
        private string country;
        private string capital;
        private int area;
        private float population;
        private string landscape;
        private bool EU;

        public Orszagok(int sorszam, string orszag, string fovaros, int terulet, float lakossag, string egtaj, bool EUtag)
        {
            this.serialnum = sorszam;
            this.country = orszag;
            this.capital = fovaros;
            this.area = terulet;
            this.population = lakossag;
            this.landscape = egtaj;
            this.EU = EUtag;
        }


        public int GetSeri()
        {
            return serialnum;
        }
        public string GetCou()
        {
            return country;
        }
        public string GetCap()
        {
            return capital;
        }
        public int GetAr()
        {
            return area;
        }
        public float GetPop()
        {
            return population;
        }
        public string GetLand()
        {
            return landscape;
        }
        public bool GetEU()
        {
            return EU;
        }

        public void SetSeri(int sorszam)
        {
            this.serialnum = sorszam;
        }
        public void SetCou(string orszag)
        {
            this.country = orszag;
        }
        public void SetCap(string fovaros)
        {
            this.capital = fovaros;
        }
        public void SetAr(int terulet)
        {
            this.area = terulet;
        }
        public void SetPop(float lakossag)
        {
            this.population = lakossag;
        }
        public void SetLand(string egtaj)
        {
            this.landscape = egtaj;
        }
        public void SetEU(bool EUtag)
        {
            this.EU = EUtag;
        }


        const char tabulator = '\t';
        const string fajl = @"Europa.txt";
        /* public void fajlbeolvas()
         {
             StreamReader sr = new StreamReader(fajl);
             while (!sr.EndOfStream)
             {
                 string[] line = sr.ReadLine().Split(tabulator);
                 GetSeri();
                 GetCou();
                 GetCap();
                 GetAr();
                 GetPop();
                 GetLand();
                 GetEU();

             }
             sr.Close();
         }*/

        public Orszagok()
        {

        }



    }
}
