﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace HD_OOP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Orszagok> olista = new List<Orszagok>(); 

        const char tabulator = '\t';
        const string fajl = @"Europa.txt";
        public void fajlbeolvas()
        {
            Orszagok beo = new Orszagok();

            StreamReader sr = new StreamReader(fajl);
            while (!sr.EndOfStream)
            {
                string[] line = sr.ReadLine().Split(tabulator);
                beo.GetSeri();
                beo.GetCou();
                beo.GetCap();
                beo.GetAr();
                beo.GetPop();
                beo.GetLand();
                beo.GetEU();
                olista.Add(beo);

            }
            sr.Close();
        }


        public void buttonAdd_Click(object sender, EventArgs e)
        {
            if (textBoxSearch.Text == "")
            {
                MessageBox.Show("Nem adtál meg minden adatot");
            }
            else
            {
                Orszagok orszag = new Orszagok();
                //olista.SetSeri = olista.Last();
                
            }
        }


        void tablaFeltolt()
        {
           foreach (Orszagok orszagok in olista) 
            {
                dataGridView1.Rows.Add(orszagok.GetSeri(),
                    orszagok.GetCou());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            fajlbeolvas();
            
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            tablaFeltolt();

            buttonAdd.Enabled = true;
            buttonSearch.Enabled = true;
        }
    }
}
